﻿'Created by: Matthew Brean
'Created on: 2016-10-02
'Created for: ICS4U
'Assignment 2b
'Rock Paper Scissors vs the pc
'

Imports System.Random

Public Class assignment2b

    Private Sub assignment2b_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ComboBox1.SelectedIndex = 0
    End Sub
    Private Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click
        Dim r As Random = New Random
        Dim rr As Integer = r.Next(3)
        Dim cChoice As Integer = rr
        Dim uChoice As Integer = ComboBox1.SelectedIndex
        Dim pcChoice As String = "Rock"
        If (cChoice = 1) Then pcChoice = "Paper"
        If (cChoice = 2) Then pcChoice = "Scissors"
        Label3.Text = pcChoice

        If (cChoice = uChoice) Then
            MsgBox("Draw!")
        Else
            If (cChoice = 0) Then
                If (uChoice = 1) Then
                    MsgBox("PC Choice: Rock" & vbNewLine & "You Win!")
                Else
                    MsgBox("PC Choice: Rock" & vbNewLine & "You Lose!")
                End If
            ElseIf (cChoice = 1) Then
                If (uChoice = 0) Then
                    MsgBox("PC Choice: Paper" & vbNewLine & "You Lose!")
                Else
                    MsgBox("PC Choice: Paper" & vbNewLine & "You Win!")
                End If
            Else
                If (uChoice = 0) Then
                    MsgBox("PC Choice: Scissors" & vbNewLine & "You Win!")
                Else
                    MsgBox("PC Choice: Scissors" & vbNewLine & "You Lose!")
                End If
            End If
        End If
        rr = Nothing
        uChoice = Nothing
        cChoice = Nothing
    End Sub


End Class


