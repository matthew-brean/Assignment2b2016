/*******************************************************************************
*
* Created by: Matthew Brean
* Created on: 2016-10-01
* Created for: ICS4U
* Assignment: 2b
* Rock Paper Scissors vs Computer
*
*******************************************************************************/

import java.util.Scanner;
import java.util.Random;

public class Assignment2 {

	public static void main(String[] args) {
		
		 System.out.println("Pick: 1 for rock, 2 for paper, 3 for scissors");
		 Scanner A2 = new Scanner(System.in);
		 int Ppick = A2.nextInt();

		 if (Ppick == 1||Ppick == 2||Ppick == 3) //|| logLength == "paper" || logLength == "scissors")
		 {
			 //communication w/ user
			 if (Ppick == 1){
				 System.out.println("You chose rock");
			 }		 
			 if (Ppick == 2){
				 System.out.println("You chose paper");
			 }		 
			 if (Ppick == 3){
				 System.out.println("You chose scissors");
			 }
		 }
		 else
		 {
		 System.out.println("You did not pick rock, paper or scissors.");
		 System.out.println("Restart to play again.");
		 }
		 
		 //randomizer
		 Random rand = new Random();
		 int Cpick = rand.nextInt(3) + 1; //1-3 # to gen
		 
		 //communication w/ user
		 if (Cpick == 1){
			 System.out.println("Computer chose rock");
		 }		 
		 if (Cpick == 2){
			 System.out.println("Computer chose paper");
		 }		 
		 if (Cpick == 3){
			 System.out.println("Computer chose scissors");
		 }
		 
		 
		 if (Cpick == 1 && Ppick == 1 ||Cpick == 2 && Ppick == 2 || Cpick == 3 && Ppick == 3){
			 System.out.println("Tie.");
			 //a=1;
		 }
		 
		 else if (Cpick == 2 && Ppick == 1 || Cpick == 1 && Ppick == 3 || Cpick == 3 && Ppick == 2){
			 System.out.println("Computer wins.");
		 }
		 else{
			 System.out.println("You win.");
		 }
	}
}